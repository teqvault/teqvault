/* ============================================================
   SIEGECRAFT POCKET — full build: 20 cards, 3 maps, meta-progression
   ============================================================ */

const COLS=9, ROWS=5, TILE=64, MARGIN=24;
// Enemy sprites rotate to face their direction of travel. Source art faces
// east by default, which matches atan2's zero angle, so no offset is needed.
// If that ever changes: Math.PI for south-facing art, -Math.PI/2 for west,
// Math.PI/2 for north.
const SPRITE_FACING_OFFSET = 0;
const cv = document.getElementById('map');
const ctx = cv.getContext('2d');
const $ = id => document.getElementById(id);
function cellCenter(c,r){ return [MARGIN + c*TILE + TILE/2, MARGIN + r*TILE + TILE/2]; }
function dist(x1,y1,x2,y2){ return Math.hypot(x1-x2,y1-y2); }
function shuffle(arr){ const a=arr.slice(); for(let i=a.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; } return a; }

/* ---------- juice: audio, particles, floating text, screen shake ---------- */
let actx = null;
function getAudio(){
  if(!actx){
    try{ actx = new (window.AudioContext||window.webkitAudioContext)(); }catch(e){ actx=false; }
  }
  return actx;
}
function tone(freq, dur, type, gain, delay){
  const ac = getAudio();
  if(!ac) return;
  const t0 = ac.currentTime + (delay||0);
  const osc = ac.createOscillator();
  const g = ac.createGain();
  osc.type = type || 'sine';
  osc.frequency.setValueAtTime(freq, t0);
  g.gain.setValueAtTime(0, t0);
  g.gain.linearRampToValueAtTime(gain||0.15, t0+0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t0+dur);
  osc.connect(g); g.connect(ac.destination);
  osc.start(t0); osc.stop(t0+dur+0.02);
}

// Real audio clips from assets/sounds/ — used when available, falling back
// to the synthesized tone() sounds above if a file is missing or fails to load.
// A few of these are best-guess assignments (marked below); easy to remesign.
const SFX_FILES = {
  clickSecondary:'click.mp3', clickPrimary:'ui-click.mp3', cancel:'Cancel.mp3', back:'Back.mp3',
  lock:'lock.mp3', unlock:'unlock.mp3', pick:'lockability.mp3', shieldHit:'hit.mp3',
  breach:'BoxHit_02.mp3', kill:'pop-7.mp3', bossKill:'combo.mp3', clear:'clear.mp3',
  win:'win.mp3', lose:'lose.mp3', fire:'ability_fire.mp3', ice:'ability_ice.mp3', light:'ability_light.mp3',
};
const sfxAudio = {};
Object.entries(SFX_FILES).forEach(([key,file])=>{
  const a = new Audio('assets/sounds/'+file);
  a.preload = 'auto';
  sfxAudio[key] = a;
});
function playFile(key, vol){
  const a = sfxAudio[key];
  if(!a || a.error) return false;
  try{
    const c = a.cloneNode(true);
    c.volume = vol===undefined ? 0.55 : vol;
    const p = c.play();
    if(p && p.catch) p.catch(()=>{});
    return true;
  }catch(e){ return false; }
}
// Firing sound grouped loosely by card theme — adjust freely, these are guesses:
const FIRE_SFX = { ember:'fire', emberstorm:'fire', wardenswall:'fire', knockback:'fire',
  frost:'ice', cryoshatter:'ice', poisonvine:'ice',
  spark:'light', twinfang:'light', longbow:'light', sniper:'light', chainbolt:'light',
  stormcaller:'light', overclock:'light', rallybanner:'light' };
function sfxFire(cardKey){ playFile(FIRE_SFX[cardKey] || 'light', 0.22); }

function sfxKill(isBoss){ if(playFile(isBoss?'bossKill':'kill', isBoss?0.6:0.4)) return; tone(isBoss?220:520+Math.random()*160, isBoss?0.4:0.09, 'square', isBoss?0.18:0.08); }
function sfxShieldSave(){ if(playFile('shieldHit',0.5)) return; tone(340,0.12,'triangle',0.15); tone(460,0.14,'triangle',0.12,0.06); }
function sfxDefeat(){ if(playFile('lose',0.6)) return; tone(220,0.5,'sawtooth',0.16); tone(160,0.6,'sawtooth',0.14,0.15); tone(90,0.8,'sawtooth',0.12,0.3); }
function sfxBreach(){ playFile('breach',0.6); }
function sfxWaveClear(){ if(playFile('clear',0.55)) return; tone(440,0.12,'triangle',0.14); tone(660,0.18,'triangle',0.14,0.1); }
function sfxVictory(){ if(playFile('win',0.65)) return; tone(440,0.16,'triangle',0.15); tone(554,0.16,'triangle',0.15,0.13); tone(660,0.3,'triangle',0.16,0.26); }
function sfxBossIntro(){ tone(120,0.5,'sawtooth',0.14); tone(90,0.6,'sawtooth',0.12,0.2); }
function sfxPick(){ if(playFile('pick',0.45)) return; tone(720,0.07,'sine',0.09); }
function sfxPlace(){ if(playFile('lock',0.5)) return; tone(300,0.08,'square',0.08); }
function sfxUpgrade(){ if(playFile('unlock',0.5)) return; tone(520,0.06,'sine',0.1); tone(780,0.09,'sine',0.1,0.05); }
function sfxCoin(){ if(playFile('unlock',0.4)) return; tone(880,0.05,'square',0.08); tone(1100,0.07,'square',0.07,0.04); }
function sfxCancel(){ playFile('cancel',0.5); }
function sfxBack(){ playFile('back',0.5); }
function sfxClick(){ playFile('clickSecondary',0.4); }
function sfxUnlock(){ playFile('unlock',0.55); }


let particles = [];
let projectiles = [];
let lightningBolts = [];
function spawnProjectile(x1,y1,x2,y2,color,target,dmg,def){
  const d = dist(x1,y1,x2,y2);
  const speed = 700;
  const dur = Math.max(80, d/speed*1000);
  projectiles.push({x:x1,y:y1,tx:x2,ty:y2,color,target,dmg,def,t:0,dur});
}
function resolveProjectileImpact(pr){
  const def = pr.def;
  const target = pr.target;
  const targetAlive = target && enemies.includes(target) && target.hp>0;
  const [ix,iy] = targetAlive ? posOnPath(target.entry, target.progress) : [pr.tx, pr.ty];
  if(targetAlive) damageEnemy(target, pr.dmg);
  burst(ix, iy, def.color, 5);
  if(def.splash){
    for(const en of enemies){
      if(en===target) continue;
      const [ex,ey] = posOnPath(en.entry, en.progress);
      if(dist(ix,iy,ex,ey) <= def.splash){
        damageEnemy(en, pr.dmg*0.6);
        if(def.dot){ en.poisonDps=def.dotDps; en.poisonT=def.dotDuration; }
      }
    }
  }
  if(def.kind==='pierce' && targetAlive){
    let hits=0;
    for(const en of enemies){
      if(en===target || en.entry!==target.entry) continue;
      if(Math.abs(en.progress-target.progress) <= def.pierceRange && hits<def.pierceCount){
        damageEnemy(en, pr.dmg); hits++;
      }
    }
  }
}
function spawnLightning(x1,y1,x2,y2){
  lightningBolts.push({x1,y1,x2,y2,life:150,maxLife:150});
}
let floatTexts = [];
let shake = 0;
function burst(x,y,color,count){
  for(let i=0;i<(count||8);i++){
    const a = Math.random()*Math.PI*2, sp = 40+Math.random()*70;
    particles.push({ x,y, vx:Math.cos(a)*sp, vy:Math.sin(a)*sp, life:400+Math.random()*200, maxLife:600, color });
  }
}
function floatText(x,y,text,color){
  floatTexts.push({ x,y, text, color, life:900, maxLife:900 });
}
function addShake(amount){ shake = Math.min(14, shake+amount); }
function showBanner(text, ms){
  const b = $('banner');
  $('bannerText').textContent = text;
  b.classList.add('show');
  clearTimeout(showBanner._t);
  showBanner._t = setTimeout(()=> b.classList.remove('show'), ms||1400);
}

/* ---------- card database (20 cards) ---------- */
const CARD_DB = {
  spark:      { name:'Spark Turret',   rarity:'common', color:'#5ec8f2', desc:'Fast, short-range, low damage.', tower:{kind:'nearest',range:85,dmg:6,rate:260} },
  longbow:    { name:'Longbow Post',   rarity:'common', color:'#c9a1f0', desc:'Long range, always hits the leader.', tower:{kind:'leader',range:180,dmg:12,rate:620} },
  ember:      { name:'Ember Cannon',   rarity:'common', color:'#f2955e', desc:'Slow, splash damage nearby.', tower:{kind:'nearest',range:105,dmg:16,rate:900,splash:46} },
  frost:      { name:'Frost Node',     rarity:'common', color:'#7ec8e3', desc:'No damage — slows all in range.', tower:{kind:'slow',range:95,slowPct:0.45} },
  mine:       { name:'Gold Mine',      rarity:'common', color:'#f5b83d', desc:'+5 gold at the end of every future wave.', utility:{effect:'goldPerWave',value:5} },
  beacon:     { name:'Repair Beacon',  rarity:'common', color:'#81c784', desc:'Absorbs the next breach. One life, once.', utility:{effect:'shield',value:1} },
  scavenger:  { name:'Scavenger Pact', rarity:'common', color:'#e8d16b', desc:'+2 gold per kill, for the rest of the run.', utility:{effect:'bountyBonus',value:2} },

  twinfang:   { name:'Twin Fang',      rarity:'rare', color:'#5ec8f2', desc:'Nearest target, higher DPS than Spark.', tower:{kind:'nearest',range:90,dmg:10,rate:200} },
  sniper:     { name:'Sniper Spire',   rarity:'rare', color:'#c9a1f0', desc:'Very long range, targets highest HP.', tower:{kind:'highhp',range:200,dmg:40,rate:1500} },
  chainbolt:  { name:'Chain Bolt',     rarity:'rare', color:'#5ec8f2', desc:'Hits the target plus enemies just behind it.', tower:{kind:'pierce',range:120,dmg:9,rate:500,pierceRange:70,pierceCount:2} },
  poisonvine: { name:'Poison Vine',    rarity:'rare', color:'#639922', desc:'Weak hit, but poisons over time.', tower:{kind:'dot',range:90,dmg:3,rate:400,dotDps:4,dotDuration:2500} },
  knockback:  { name:'Knockback Ram',  rarity:'rare', color:'#e8d16b', desc:'No damage — shoves the leader backward.', tower:{kind:'knockback',range:100,dmg:0,rate:1200,knockAmount:40} },
  interest:   { name:'Interest Vault', rarity:'rare', color:'#f5b83d', desc:'Gain 10% of your gold as interest each wave.', utility:{effect:'interest',value:0.10} },
  overclock:  { name:'Overclock Beacon', rarity:'rare', color:'#e57373', desc:'Aura — nearby towers fire 30% faster.', tower:{kind:'auraRate',range:90,rateMult:0.30} },
  rallybanner:{ name:'Rally Banner',   rarity:'rare', color:'#f2955e', desc:'Aura — nearby towers deal 25% more damage.', tower:{kind:'auraDmg',range:90,dmgMult:0.25} },

  stormcaller:{ name:'Stormcaller',    rarity:'epic', color:'#7f77dd', desc:'Lightning chains to up to 4 enemies.', tower:{kind:'chain',range:110,dmg:10,rate:700,chainCount:4,chainRange:70} },
  wardenswall:{ name:"Warden's Wall",  rarity:'epic', color:'#993c1d', desc:'Enormous single hit, very slow fire rate.', tower:{kind:'nearest',range:130,dmg:70,rate:1800} },
  cryoshatter:{ name:'Cryoshatter',    rarity:'epic', color:'#5dcaa5', desc:'Weak alone — massive bonus vs slowed enemies.', tower:{kind:'slowbonus',range:100,dmg:4,slowDmgMult:4,rate:350} },
  emberstorm: { name:'Emberstorm',     rarity:'epic', color:'#d85a30', desc:'Splash damage that also ignites enemies.', tower:{kind:'nearest',range:105,dmg:14,rate:850,splash:50,dot:true,dotDps:5,dotDuration:2000} },
  laststand:  { name:'Last Stand Beacon', rarity:'epic', color:'#639922', desc:'Absorbs the next 2 breaches.', utility:{effect:'shield',value:2} },
};
const ALL_CARD_KEYS = Object.keys(CARD_DB);
const RARITY_COST = { common:0, rare:30, epic:55 };
const STARTER_CARDS = ['spark','longbow','ember','frost','mine','beacon','scavenger'];

/* ---------- sprites: wired to the actual TeqGames/assets/images structure.
   UI card icons (draft/armory/hand/upgrade panel) -> assets/images/armory/<key>.png
   Board tower sprites                              -> assets/images/weapons/<mapped>.png
   Enemies (not yet supplied)                        -> assets/images/enemies/{grunt,runner,boss}.png
   Anything missing falls back to the flat colored shape automatically.
   ---------------------------------------------------------------------------- */
const sprites = {};
function loadSprite(key, path){
  const im = new Image();
  im.src = 'assets/images/' + path;
  sprites[key] = im;
}
function spriteReady(key){
  const im = sprites[key];
  return !!(im && im.complete && im.naturalWidth > 0);
}

// armory/ filenames match CARD_DB keys directly, except this one typo:
const ARMORY_ALIAS = { overclock: 'overlock' };
function armoryIconUrl(key){
  return 'assets/images/armory/' + (ARMORY_ALIAS[key] || key) + '.png';
}

// weapons/ (board sprites) use descriptive filenames instead of card keys.
// weapons_icons_01_19/20 are unlabeled — guessed as overclock/emberstorm below;
// tell me if that's backwards and it's a one-line swap.
const WEAPON_FILE = {
  spark:'sparkturret', longbow:'longbowpost', ember:'embercannon', frost:'frostnode',
  mine:'goldmine', beacon:'repairbeacon', scavenger:'scavengerpact', twinfang:'twinfang',
  sniper:'sniperspire', chainbolt:'chainbolt', poisonvine:'poisonvine', knockback:'knockbackram',
  interest:'inetrestvault', overclock:'weapons_icons_01_19', rallybanner:'rallybanner',
  stormcaller:'stormcaller', wardenswall:'wardenswall', cryoshatter:'cryoshatter',
  emberstorm:'weapons_icons_01_20', laststand:'laststandbeacon',
};

ALL_CARD_KEYS.forEach(key => loadSprite('armory:'+key, 'armory/' + (ARMORY_ALIAS[key]||key) + '.png'));
ALL_CARD_KEYS.forEach(key => loadSprite('card:'+key, 'weapons/' + WEAPON_FILE[key] + '.png'));
['grunt','runner','boss','brute','swarmling','shielded','regenerator'].forEach(k => loadSprite('enemy:'+k, 'enemies/'+k+'.png'));
loadSprite('tile:floor', 'Tile_1.png');
loadSprite('tile:path', 'Tile_2.png');
loadSprite('marker:start', 'enemyspawn.png');
loadSprite('marker:end', 'playerspawn.png');


/* ---------- maps ---------- */
const PATH_SINGLE = [
  [0,0],[1,0],[2,0],[3,0],[4,0],[5,0],[6,0],[7,0],[8,0],
  [8,1],[8,2],
  [7,2],[6,2],[5,2],[4,2],[3,2],[2,2],[1,2],[0,2],
  [0,3],[0,4],
  [1,4],[2,4],[3,4],[4,4],[5,4],[6,4],[7,4],[8,4],
];
const PATH_FOG = [
  [0,2],[1,2],[2,2],[2,1],[2,0],[3,0],[4,0],[5,0],[5,1],
  [5,2],[6,2],[6,3],[6,4],[7,4],[8,4],
];
const DUAL_A = [[0,0],[1,0],[2,0],[3,0],[4,0],[4,1],[4,2]];
const DUAL_B = [[0,4],[1,4],[2,4],[3,4],[4,4],[4,3],[4,2]];
const DUAL_TAIL = [[4,2],[5,2],[6,2],[7,2],[8,2]];
const TRIPLE_A = [[0,0],[1,0],[2,0],[3,0],[4,0],[4,1],[4,2]];
const TRIPLE_B = [[0,2],[1,2],[2,2],[3,2],[4,2]];
const TRIPLE_C = [[0,4],[1,4],[2,4],[3,4],[4,4],[4,3],[4,2]];
const TRIPLE_TAIL = [[4,2],[5,2],[6,2],[7,2],[8,2]];

// Every map's geometry is just a list of entry lanes (1, 2, 3+) that all
// eventually reach the same exit. A single-lane map is just entries.length===1.
function buildGeo(entryCellsList, tailCells){
  tailCells = tailCells || null;
  const entries = entryCellsList.map((cells,i)=>{
    const full = tailCells ? cells.concat(tailCells.slice(1)) : cells;
    const waypoints = full.map(([c,r])=>cellCenter(c,r));
    return { label:String.fromCharCode(65+i), waypoints, totalLen:(waypoints.length-1)*TILE };
  });
  const allCells = tailCells ? [...entryCellsList.flat(), ...tailCells] : entryCellsList.flat();
  const pathSet = new Set(allCells.map(([c,r])=>c+','+r));
  return { entries, pathSet };
}

const MAPS = {
  frontier: { id:'frontier', name:'Frontier Line', desc:'The original approach. One road, nine waves of pressure.', cost:0, maxWaves:10, geo:buildGeo([PATH_SINGLE]), embersPerWave:3, embersWin:20,
    waveFn:(n)=>standardWave(n) },
  twinroads: { id:'twinroads', name:'Twin Roads', desc:'Two roads converge into one. Cover both, or don\u2019t bother.', cost:40, maxWaves:10, geo:buildGeo([DUAL_A,DUAL_B], DUAL_TAIL), embersPerWave:3, embersWin:20,
    waveFn:(n)=>standardWave(n) },
  bossrush: { id:'bossrush', name:'Boss Rush', desc:'No minions. Three escalating champions, back to back.', cost:70, maxWaves:3, geo:buildGeo([PATH_SINGLE]), embersPerWave:15, embersWin:40,
    waveFn:(n)=>bossRushWave(n) },
  fogline: { id:'fogline', name:'The Fog Line', desc:'You only see what your towers cover. Everything else is blind.', cost:55, maxWaves:10, geo:buildGeo([PATH_FOG]), embersPerWave:4, embersWin:25,
    waveFn:(n)=>standardWave(n), fogOfWar:true },
  triple: { id:'triple', name:'Triple Descent', desc:'Three roads converge into one. Spread thin, or lose a lane.', cost:90, maxWaves:10, geo:buildGeo([TRIPLE_A,TRIPLE_B,TRIPLE_C], TRIPLE_TAIL), embersPerWave:4, embersWin:25,
    waveFn:(n)=>standardWave(n) },
};

function enemyPoolForWave(n){
  const pool = ['grunt'];
  if(n>=3) pool.push('swarmling');
  if(n>=4) pool.push('runner');
  if(n>=6) pool.push('regenerator');
  if(n>=7) pool.push('shielded');
  if(n>=8) pool.push('brute');
  return pool;
}
function standardWave(n){
  const count = 5+n;
  const pool = enemyPoolForWave(n);
  const list=[];
  for(let i=0;i<count;i++){
    const kind = pool[Math.floor(Math.random()*pool.length)];
    list.push(enemySpec(kind,n));
  }
  return list;
}
function bossRushWave(n){
  if(n===1) return [ enemySpec('boss', 4) ];
  if(n===2) return [ enemySpec('boss', 8) ];
  return [ enemySpec('boss', 12) ];
}
const ENEMY_COLOR = {
  grunt:'#c9a1f0', runner:'#f5b83d', boss:'#e57373',
  brute:'#993c1d', swarmling:'#81c784', shielded:'#5ec8f2', regenerator:'#5dcaa5',
};
function enemySpec(kind,n){
  if(kind==='grunt') return { kind, hp:18+n*8, speed:42+n*1.5, leak:1, bounty:3+Math.floor(n/2) };
  if(kind==='runner') return { kind, hp:10+n*5, speed:78+n*2, leak:1, bounty:4+Math.floor(n/2) };
  if(kind==='brute') return { kind, hp:60+n*16, speed:26+n*0.8, leak:2, bounty:8+n };
  if(kind==='swarmling') return { kind, hp:6+n*2, speed:60+n*1.8, leak:1, bounty:2 };
  if(kind==='shielded') return { kind, hp:16+n*7, shield:20+n*6, speed:40+n*1.4, leak:1, bounty:6+n };
  if(kind==='regenerator') return { kind, hp:24+n*9, regen:2+Math.floor(n/3), speed:38+n*1.3, leak:1, bounty:7+n };
  if(kind==='boss') return { kind, hp:380+n*55, speed:24, leak:5, bounty:60+n*4 };
}

/* ---------- meta persistence ---------- */
let meta = { embers:0, unlockedCards: STARTER_CARDS.slice(), unlockedMaps:['frontier'], upgrades:{prospector:0}, missions:{} };
const MISSION_DEFS = [
  { key:'flawless',   name:'Flawless',   desc:'Win without a single breach getting through.', bonus:15 },
  { key:'minimalist', name:'Minimalist', desc:'Win using 4 or fewer distinct tower types.',    bonus:15 },
  { key:'frugal',     name:'Frugal',     desc:'Win without ever rerolling a draft.',           bonus:15 },
];
let storageOK = true;
async function loadMeta(){
  try{
    const res = await window.storage.get('siegecraft:meta');
    if(res && res.value){
      const m = JSON.parse(res.value);
      meta = Object.assign(meta, m);
      meta.unlockedCards = Array.from(new Set([...STARTER_CARDS, ...(m.unlockedCards||[])]));
    }
  }catch(e){ if(!window.storage) storageOK=false; }
}
async function saveMeta(){
  if(!storageOK) return;
  try{ await window.storage.set('siegecraft:meta', JSON.stringify(meta)); }catch(e){}
}

/* ---------- run state ---------- */
let selectedMapId = 'frontier';
let map = null;
let shields, gold, wave, buildable, towers, enemies, handCard, draftUsedThisWave, rerollsThisDraft;
let selectedTower, shieldsPurchased;
let goldDisplay = 0, embersDisplay = 0;
let breachesThisRun, towersUsedThisRun, totalRerollsThisRun;
let goldPerWaveBonus, bountyBonus, interestPct;
let spawnQueue, spawnTimer, spawnEntryToggle;
let phase = 'menu';
let lastT = 0;
let speedMult = 1;

/* ---------- menu ---------- */
function renderMenu(){
  const el = $('menuMaps'); el.innerHTML='';
  Object.values(MAPS).forEach(m=>{
    const unlocked = meta.unlockedMaps.includes(m.id);
    const div = document.createElement('div');
    div.className = 'mapcard' + (m.id===selectedMapId?' selected':'') + (!unlocked?' locked':'');
    const doneMap = meta.missions[m.id] || {};
    const missionLine = unlocked
      ? '<div style="font-size:10px;color:var(--dim);margin-top:6px;display:flex;gap:10px">' +
        MISSION_DEFS.map(md => `<span style="color:${doneMap[md.key]?'var(--amber)':'var(--dim)'}">${doneMap[md.key]?'\u2713':'\u25cb'} ${md.name}</span>`).join('') +
        '</div>'
      : '';
    div.innerHTML = `<div><div class="mt">${m.name}${!unlocked?' \ud83d\udd12':''}</div><div class="md">${m.desc}</div>${missionLine}</div>
      <div class="mc">${unlocked ? (m.id===selectedMapId?'SELECTED':'') : m.cost+' embers'}</div>`;
    div.addEventListener('click', ()=>{
      if(unlocked){ selectedMapId = m.id; sfxClick(); renderMenu(); }
      else if(meta.embers >= m.cost){
        meta.embers -= m.cost; meta.unlockedMaps.push(m.id); saveMeta();
        sfxUnlock();
        selectedMapId = m.id; toast('Unlocked ' + m.name); renderMenu();
      } else toast('Not enough embers');
    });
    el.appendChild(div);
  });
  $('beginBtn').disabled = !meta.unlockedMaps.includes(selectedMapId);
}
$('beginBtn').addEventListener('click', ()=>{
  $('menuVeil').classList.remove('show');
  startRun(selectedMapId);
});
$('menuBtn').addEventListener('click', ()=>{
  if(phase==='victory-pending') return;
  const runActive = map && phase!=='menu' && phase!=='ended';
  if(runActive){
    $('draftVeil').classList.remove('show');
    finishRun(false, true);
    return;
  }
  sfxBack();
  phase='menu';
  $('menuVeil').classList.add('show');
  renderMenu();
});

/* ---------- armory ---------- */
$('armoryBtn').addEventListener('click', ()=>{
  const el = $('armGrid'); el.innerHTML='';
  ALL_CARD_KEYS.forEach(key=>{
    const def = CARD_DB[key];
    const unlocked = meta.unlockedCards.includes(key);
    const cost = RARITY_COST[def.rarity];
    const div = document.createElement('div');
    div.className = 'armCard ' + def.rarity + (unlocked?'':' locked');
    div.innerHTML = `<div class="icon" style="background:${def.color} url('${armoryIconUrl(key)}') center/cover"></div>
      <div class="t">${def.name}</div>
      <div class="d">${def.desc}</div>
      <button ${unlocked? 'disabled' : ''}>${unlocked ? 'UNLOCKED' : 'UNLOCK \u00b7 '+cost}</button>`;
    if(!unlocked){
      div.querySelector('button').addEventListener('click', ()=>{
        if(meta.embers < cost){ toast('Not enough embers'); return; }
        meta.embers -= cost; meta.unlockedCards.push(key); saveMeta();
        sfxUnlock();
        toast('Unlocked ' + def.name);
        $('armoryBtn').click();
        renderMenu();
      });
    }
    el.appendChild(div);
  });
  $('armoryVeil').classList.add('show');
});
$('armCloseBtn').addEventListener('click', ()=>{ sfxBack(); $('armoryVeil').classList.remove('show'); });

/* ---------- upgrades ---------- */
const UPGRADE_DEFS = {
  prospector: { name:'Prospector', effect:'+10 starting gold', base:15, step:10, max:3 },
};
$('upgradesBtn').addEventListener('click', ()=>{
  const el = $('upList'); el.innerHTML='';
  Object.entries(UPGRADE_DEFS).forEach(([key,def])=>{
    const lvl = meta.upgrades[key]||0;
    const cost = def.base + lvl*def.step;
    const maxed = lvl>=def.max;
    const div = document.createElement('div'); div.className='upRow';
    div.innerHTML = `<div><div class="ut">${def.name} (Lv.${lvl}/${def.max})</div><div class="ud">${def.effect} per level</div></div>
      <button ${maxed?'disabled':''}>${maxed?'MAXED':'BUY \u00b7 '+cost}</button>`;
    if(!maxed){
      div.querySelector('button').addEventListener('click', ()=>{
        if(meta.embers < cost){ toast('Not enough embers'); return; }
        meta.embers -= cost; meta.upgrades[key] = lvl+1; saveMeta();
        sfxUnlock();
        $('upgradesBtn').click(); renderMenu();
      });
    }
    el.appendChild(div);
  });
  $('upgradesVeil').classList.add('show');
});
$('upCloseBtn').addEventListener('click', ()=>{ sfxBack(); $('upgradesVeil').classList.remove('show'); });

/* ---------- run lifecycle ---------- */
function startRun(mapId){
  map = MAPS[mapId];
  const prospLvl = meta.upgrades.prospector||0;
  shields = 0; shieldsPurchased = 0; selectedTower = null;
  gold = 30 + prospLvl*10;
  goldDisplay = gold;
  wave = 0;
  towers = []; enemies = [];
  handCard = null; draftUsedThisWave=false; rerollsThisDraft=0;
  goldPerWaveBonus = 0; bountyBonus = 0; interestPct = 0;
  breachesThisRun = 0; towersUsedThisRun = new Set(); totalRerollsThisRun = 0;
  buildable = [];
  for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++){
    if(!map.geo.pathSet.has(c+','+r)) buildable.push({c,r,occupied:null});
  }
  phase = 'idle';
  $('maxWaveVal').textContent = map.maxWaves;
  $('waveLabel').textContent = map.id==='bossrush' ? 'CHAMPION' : 'WAVE';
  updateHUD(); renderHand(); renderTowerPanel(); checkWaveReady(); draw();
}

/* ---------- gold sinks: buy shield, upgrade towers ---------- */
function shieldCost(){ return 25 + shieldsPurchased*15; }
function refreshShieldCost(){
  const cost = shieldCost();
  $('shieldCost').textContent = '+'+cost+'g';
  $('buyShieldBtn').style.opacity = gold>=cost ? '1' : '.5';
}
$('buyShieldBtn').addEventListener('click', ()=>{
  if(!map || phase==='ended' || phase==='menu') return;
  const cost = shieldCost();
  if(gold < cost){ toast('Not enough gold'); return; }
  gold -= cost; shieldsPurchased++; shields++;
  updateHUD();
  sfxCoin();
  toast('+1 shield purchased');
});

const TOWER_MAX_LEVEL = 3;
function towerUpgradeCost(t){ return 20 * t.level; }
function getEffectiveDef(t){
  const base = CARD_DB[t.key].tower;
  const mult = 1 + 0.25*(t.level-1);
  const eff = Object.assign({}, base);
  if(base.dmg) eff.dmg = base.dmg * mult;
  if(base.kind==='slow') eff.slowPct = Math.min(0.75, base.slowPct + 0.08*(t.level-1));
  if(base.kind==='knockback') eff.knockAmount = base.knockAmount + 15*(t.level-1);
  if(base.kind==='auraDmg') eff.dmgMult = base.dmgMult + 0.08*(t.level-1);
  if(base.kind==='auraRate') eff.rateMult = base.rateMult + 0.08*(t.level-1);
  return eff;
}
function renderTowerPanel(){
  const el = $('towerPanel');
  if(!selectedTower){ el.style.display='none'; return; }
  el.style.display='flex';
  const def = CARD_DB[selectedTower.key];
  const lvl = selectedTower.level;
  const maxed = lvl >= TOWER_MAX_LEVEL;
  const cost = towerUpgradeCost(selectedTower);
  el.innerHTML = `<div class="handcard">
      <div class="sw" style="background:${def.color} url('${armoryIconUrl(selectedTower.key)}') center/cover"></div>
      <div><div class="t">${def.name} &middot; Lv.${lvl}/${TOWER_MAX_LEVEL}</div><div class="d">${def.desc}</div></div>
    </div>
    <button class="act" id="upgradeTowerBtn" style="flex:0 0 auto; padding:8px 14px;" ${maxed?'disabled':(gold<cost?'disabled':'')}>${maxed?'MAXED':'UPGRADE \u00b7 '+cost}</button>
    <button class="act" id="deselectTowerBtn" style="flex:0 0 auto; padding:8px 14px;">DONE</button>`;
  if(!maxed){
    $('upgradeTowerBtn').addEventListener('click', ()=>{
      if(gold < cost) return;
      gold -= cost; selectedTower.level++;
      sfxUpgrade();
      updateHUD(); renderTowerPanel();
    });
  }
  $('deselectTowerBtn').addEventListener('click', ()=>{ sfxBack(); selectedTower=null; renderTowerPanel(); draw(); });
}

/* ---------- draft ---------- */
function rarityWeightsForWave(n){
  if(n<=3) return {common:70,rare:25,epic:5};
  if(n<=7) return {common:45,rare:40,epic:15};
  return {common:25,rare:45,epic:30};
}
function weightedSample(pool, weights, count){
  const bag=[];
  pool.forEach(key=>{
    const r = CARD_DB[key].rarity;
    const w = weights[r];
    for(let i=0;i<w;i++) bag.push(key);
  });
  const chosen=[]; const used=new Set();
  let attempts=0;
  while(chosen.length<count && attempts<400){
    attempts++;
    const pick = bag[Math.floor(Math.random()*bag.length)];
    if(!used.has(pick)){ used.add(pick); chosen.push(pick); }
  }
  while(chosen.length<count && chosen.length<pool.length){
    const remaining = pool.filter(k=>!used.has(k));
    if(!remaining.length) break;
    const pick = remaining[Math.floor(Math.random()*remaining.length)];
    used.add(pick); chosen.push(pick);
  }
  return chosen;
}
function openDraft(){
  if(draftUsedThisWave || phase==='wave' || phase==='victory-pending') return;
  sfxClick();
  phase='draft';
  rerollsThisDraft = 0;
  renderDraftChoices();
  $('draftVeil').classList.add('show');
}
function renderDraftChoices(){
  const weights = rarityWeightsForWave(wave+1);
  const pool = meta.unlockedCards.slice();
  const picks = weightedSample(pool, weights, Math.min(3,pool.length));
  const el = $('cardChoices'); el.innerHTML='';
  picks.forEach(key=>{
    const def = CARD_DB[key];
    const card = document.createElement('div');
    card.className = 'cardopt ' + def.rarity;
    card.innerHTML = `<span class="rarity">${def.rarity.toUpperCase()}</span>
      <div class="icon" style="background:${def.color} url('${armoryIconUrl(key)}') center/cover"></div>
      <div class="t">${def.name}</div>
      <div class="d">${def.desc}</div>`;
    card.addEventListener('click', ()=>{
      handCard = { key, type: def.tower ? 'tower':'utility' };
      draftUsedThisWave = true;
      $('draftVeil').classList.remove('show');
      sfxPick();
      if(def.utility) resolveUtility(key);
      renderHand(); checkWaveReady();
    });
    el.appendChild(card);
  });
  const cost = 15 + rerollsThisDraft*7;
  $('rerollCost').textContent = cost;
  $('rerollBtn').disabled = gold < cost;
}
$('draftBtn').addEventListener('click', openDraft);
$('rerollBtn').addEventListener('click', ()=>{
  const cost = 15 + rerollsThisDraft*7;
  if(gold < cost) return;
  gold -= cost; rerollsThisDraft++; totalRerollsThisRun++;
  updateHUD();
  renderDraftChoices();
});
$('skipBtn').addEventListener('click', ()=>{
  gold += 10;
  draftUsedThisWave = true;
  sfxCancel();
  $('draftVeil').classList.remove('show');
  updateHUD();
  toast('+10 gold');
  checkWaveReady();
});

function resolveUtility(key){
  const def = CARD_DB[key].utility;
  if(def.effect==='goldPerWave') goldPerWaveBonus += def.value;
  if(def.effect==='shield'){ shields += def.value; toast('+'+def.value+' shield'+(def.value>1?'s':'')+' — next breach'+(def.value>1?'es':'')+' absorbed'); }
  if(def.effect==='bountyBonus') bountyBonus += def.value;
  if(def.effect==='interest') interestPct += def.value;
  handCard = null;
  updateHUD();
}

/* ---------- hand / placement ---------- */
function renderHand(){
  const el = $('hand'); el.innerHTML='';
  if(!handCard){ el.innerHTML = '<span class="empty">'+(draftUsedThisWave?'No card in hand':'Draft a card to begin')+'</span>'; return; }
  const def = CARD_DB[handCard.key];
  el.innerHTML = `<div class="handcard">
      <div class="sw" style="background:${def.color} url('${armoryIconUrl(handCard.key)}') center/cover"></div>
      <div><div class="t">${def.name}</div><div class="d">${def.desc}</div></div>
    </div>
    <span class="handtip">Tap an open tile to build</span>
    <button class="act" id="cancelCardBtn" style="flex:0 0 auto; padding:8px 12px;">CANCEL</button>`;
  $('cancelCardBtn').addEventListener('click', ()=>{
    handCard = null;
    sfxCancel();
    renderHand(); checkWaveReady(); draw();
    toast('Card discarded');
  });
}
cv.addEventListener('click', e=>{
  const r = cv.getBoundingClientRect();
  const x = (e.clientX-r.left) * (cv.width/r.width);
  const y = (e.clientY-r.top) * (cv.height/r.height);

  if(handCard && handCard.type==='tower'){
    const c = Math.floor((x-MARGIN)/TILE), row = Math.floor((y-MARGIN)/TILE);
    const spot = buildable.find(b=>b.c===c && b.r===row);
    if(!spot || spot.occupied) return;
    const [cx,cy] = cellCenter(c,row);
    spot.occupied = handCard.key;
    towers.push({ c, r:row, x:cx, y:cy, key:handCard.key, cooldown:0, level:1, spawnAnim:300 });
    towersUsedThisRun.add(handCard.key);
    handCard = null;
    sfxPlace();
    renderHand(); draw(); checkWaveReady();
    return;
  }

  const hit = towers.find(t => dist(t.x,t.y,x,y) <= 24);
  selectedTower = hit || null;
  renderTowerPanel(); draw();
});
function checkWaveReady(){
  $('waveBtn').disabled = !!handCard || phase==='wave' || !draftUsedThisWave;
  $('draftBtn').disabled = phase==='wave' || draftUsedThisWave;
}

/* ---------- wave flow ---------- */
$('waveBtn').addEventListener('click', ()=>{
  if(handCard || phase==='wave' || !draftUsedThisWave) return;
  wave++;
  spawnQueue = map.waveFn(wave);
  spawnTimer = 0; spawnEntryToggle = 0;
  enemies = [];
  phase = 'wave';
  updateHUD(); checkWaveReady();
});
function endWave(){
  phase = 'idle';
  gold += 8 + goldPerWaveBonus;
  if(interestPct>0) gold += Math.floor(gold*interestPct);
  draftUsedThisWave = false;
  updateHUD();
  if(wave >= map.maxWaves){
    phase = 'victory-pending';
    addShake(10);
    showBanner('VICTORY', 1000);
    const cx = MARGIN + (COLS*TILE)/2, cy = MARGIN + (ROWS*TILE)/2;
    burst(cx, cy, '#f5b83d', 26);
    burst(cx, cy, '#c9a1f0', 18);
    setTimeout(()=>finishRun(true), 900);
    return;
  }
  checkWaveReady(); renderHand();
  sfxWaveClear();
  showBanner(map.id==='bossrush' ? 'CHAMPION ' + wave + ' DEFEATED' : 'WAVE ' + wave + ' CLEARED', 1300);
  toast('Draft your next card');
}
function breach(){
  if(phase==='ended') return;
  breachesThisRun++;
  if(shields>0){
    shields--;
    updateHUD();
    sfxShieldSave();
    addShake(5);
    toast('Shield absorbed the breach' + (shields>0 ? ' — '+shields+' left' : ''));
    return;
  }
  addShake(12);
  sfxBreach();
  finishRun(false);
}
async function finishRun(victory, forfeited){
  if(phase==='ended') return;
  phase='ended';
  if(forfeited) sfxPick(); else victory ? sfxVictory() : sfxDefeat();
  let embers = wave*map.embersPerWave + (victory?map.embersWin:0);

  const newlyCompleted = [];
  if(victory){
    if(!meta.missions[map.id]) meta.missions[map.id] = {};
    const runValues = {
      flawless: breachesThisRun===0,
      minimalist: towersUsedThisRun.size<=4,
      frugal: totalRerollsThisRun===0,
    };
    MISSION_DEFS.forEach(mDef=>{
      if(runValues[mDef.key] && !meta.missions[map.id][mDef.key]){
        meta.missions[map.id][mDef.key] = true;
        embers += mDef.bonus;
        newlyCompleted.push(mDef);
      }
    });
  }

  meta.embers += embers;
  await saveMeta();
  $('endTitle').textContent = victory ? 'EYUFORYIA HOLDS' : (forfeited ? 'WITHDRAWN' : 'THE LINE BROKE');
  $('endText').textContent = victory
    ? 'All ' + map.maxWaves + ' waves repelled on ' + map.name + '. The siege is over — for now.'
    : forfeited
      ? 'You withdrew from ' + map.name + ' after wave ' + wave + ' of ' + map.maxWaves + '. Your progress still counts.'
      : 'You held through wave ' + wave + ' of ' + map.maxWaves + ' on ' + map.name + '.';
  $('endEmbers').textContent = '+' + embers + ' embers earned';
  const missionsEl = $('endMissions');
  if(newlyCompleted.length){
    missionsEl.style.display = 'block';
    missionsEl.textContent = 'Mission complete: ' + newlyCompleted.map(m=>m.name).join(', ');
  } else {
    missionsEl.style.display = 'none';
  }
  $('endVeil').classList.add('show');
}
$('endBtn').addEventListener('click', ()=>{
  $('endVeil').classList.remove('show');
  phase='menu';
  $('menuVeil').classList.add('show');
  renderMenu();
});

/* ---------- combat ---------- */
function laneFor(entry){
  return map.geo.entries.find(e=>e.label===entry) || map.geo.entries[0];
}
function posOnPath(entry, progress){
  const lane = laneFor(entry);
  return posAtProgress(lane.waypoints, lane.totalLen, progress);
}
function totalLenFor(entry){
  return laneFor(entry).totalLen;
}
function posAtProgress(waypoints, totalLen, p){
  p = Math.max(0, Math.min(p, totalLen));
  const segIdx = Math.min(Math.floor(p/TILE), waypoints.length-2);
  const t = (p - segIdx*TILE)/TILE;
  const [ax,ay] = waypoints[segIdx], [bx,by] = waypoints[segIdx+1];
  return [ax+(bx-ax)*t, ay+(by-ay)*t];
}
function angleOnPath(entry, progress){
  const lane = laneFor(entry);
  return angleAtProgress(lane.waypoints, lane.totalLen, progress);
}
function angleAtProgress(waypoints, totalLen, p){
  p = Math.max(0, Math.min(p, totalLen));
  const segIdx = Math.min(Math.floor(p/TILE), waypoints.length-2);
  const [ax,ay] = waypoints[segIdx], [bx,by] = waypoints[segIdx+1];
  return Math.atan2(by-ay, bx-ax);
}
function lerpAngle(a, b, t){
  let diff = ((b - a + Math.PI) % (Math.PI*2)) - Math.PI;
  if(diff < -Math.PI) diff += Math.PI*2;
  return a + diff*Math.min(1, Math.max(0, t));
}
function easeOutBack(t){
  const c1=1.70158, c3=c1+1;
  return 1 + c3*Math.pow(t-1,3) + c1*Math.pow(t-1,2);
}

function damageEnemy(en, dmg, showNumber){
  if(dmg<=0) return;
  const dealt = dmg;
  if(en.shield>0){
    const absorbed = Math.min(en.shield, dmg);
    en.shield -= absorbed;
    dmg -= absorbed;
  }
  if(dmg>0) en.hp -= dmg;
  if(showNumber!==false && dealt>=1){
    const [ex,ey] = posOnPath(en.entry, en.progress);
    floatText(ex+(Math.random()*10-5), ey-6, '-'+Math.round(dealt), dmg<dealt?'#5ec8f2':'#e8eaf2');
  }
}
function getAuraBonus(t){
  let dmgMult=1, rateMult=1;
  for(const o of towers){
    if(o===t) continue;
    const obase = CARD_DB[o.key].tower;
    if(!obase) continue;
    if(obase.kind==='auraDmg' && dist(o.x,o.y,t.x,t.y)<=obase.range){
      const oeff = getEffectiveDef(o);
      dmgMult += oeff.dmgMult;
    }
    if(obase.kind==='auraRate' && dist(o.x,o.y,t.x,t.y)<=obase.range){
      const oeff = getEffectiveDef(o);
      rateMult -= oeff.rateMult;
    }
  }
  return { dmgMult, rateMult: Math.max(0.25, rateMult) };
}

function updateGame(dt){
  if(phase!=='wave') return;

  spawnTimer -= dt;
  if(spawnTimer<=0 && spawnQueue.length){
    const spec = spawnQueue.shift();
    const entry = map.geo.entries[spawnEntryToggle % map.geo.entries.length].label;
    spawnEntryToggle++;
    enemies.push({ progress:0, hp:spec.hp, maxHp:spec.hp, baseSpeed:spec.speed, speed:spec.speed,
                   leak:spec.leak, kind:spec.kind, bounty:spec.bounty, slowT:0, entry,
                   poisonDps:0, poisonT:0, shield:spec.shield||0, maxShield:spec.shield||0, regen:spec.regen||0,
                   pulseSeed:Math.random()*1000 });
    spawnTimer = spec.kind==='boss' ? 0 : 460;
    if(spec.kind==='boss'){
      const bossBanners = map.id==='bossrush'
        ? ['','FIRST CHAMPION APPROACHES','SECOND CHAMPION APPROACHES','FINAL CHAMPION APPROACHES']
        : null;
      showBanner(bossBanners ? bossBanners[wave] : 'A CHAMPION APPROACHES', 1600);
      sfxBossIntro();
    }
  }

  for(const t of towers){
    const def = getEffectiveDef(t);
    if(def.kind==='slow'){
      for(const en of enemies){
        const [ex,ey] = posOnPath(en.entry, en.progress);
        if(dist(t.x,t.y,ex,ey) <= def.range) en.slowT = 220;
      }
      continue;
    }
    if(def.kind==='auraDmg' || def.kind==='auraRate') continue;

    t.cooldown -= dt;
    if(t.cooldown>0) continue;
    const bonus = getAuraBonus(t);

    let target=null, bestVal=-1;
    for(const en of enemies){
      const [ex,ey] = posOnPath(en.entry, en.progress);
      if(dist(t.x,t.y,ex,ey) > def.range) continue;
      if(def.kind==='leader'){ if(en.progress>bestVal){bestVal=en.progress; target=en;} }
      else if(def.kind==='highhp'){ if(en.hp>bestVal){bestVal=en.hp; target=en;} }
      else if(def.kind==='slowbonus'){ if(en.slowT>0){ target=en; bestVal=1e9; break; } if(bestVal===-1){bestVal=0; target=en;} }
      else { const d=dist(t.x,t.y,ex,ey); if(bestVal===-1||d<bestVal){bestVal=d; target=en;} }
    }
    if(!target) continue;

    let dmg = def.dmg * bonus.dmgMult;
    if(def.kind==='slowbonus') dmg = target.slowT>0 ? def.dmg*def.slowDmgMult*bonus.dmgMult : def.dmg*bonus.dmgMult;
    sfxFire(t.key);
    t.recoil = 150;

    if(def.kind==='knockback'){
      target.progress = Math.max(0, target.progress - def.knockAmount);
      t.flash=90; t.flashTarget=target;
    } else {
      const [tgx,tgy] = posOnPath(target.entry, target.progress);
      spawnProjectile(t.x, t.y, tgx, tgy, def.color, target, dmg, def);
      t.flash=90;
      if(def.dot || def.kind==='dot'){
        target.poisonDps = def.dotDps; target.poisonT = def.dotDuration;
      }
      if(def.kind==='chain'){
        const [tx,ty] = posOnPath(target.entry, target.progress);
        let hits=1;
        let fromX=tx, fromY=ty;
        for(const en of enemies){
          if(en===target || hits>=def.chainCount) continue;
          const [ex,ey] = posOnPath(en.entry, en.progress);
          if(dist(fromX,fromY,ex,ey) <= def.chainRange){
            damageEnemy(en, dmg);
            spawnLightning(fromX, fromY, ex, ey);
            fromX=ex; fromY=ey;
            hits++;
          }
        }
      }
    }
    t.cooldown = def.rate * bonus.rateMult;
  }

  for(let i=enemies.length-1;i>=0;i--){
    const en = enemies[i];
    if(en.slowT>0){ en.slowT -= dt; en.speed = en.baseSpeed*0.55; } else en.speed = en.baseSpeed;
    if(en.poisonT>0){ damageEnemy(en, en.poisonDps*dt/1000, false); en.poisonT -= dt; }
    if(en.regen>0 && en.hp>0){ en.hp = Math.min(en.maxHp, en.hp + en.regen*dt/1000); }
    const targetAngle = angleOnPath(en.entry, en.progress);
    en.facing = lerpAngle(en.facing===undefined ? targetAngle : en.facing, targetAngle, dt/120);
    if(en.hp<=0){
      gold += en.bounty + bountyBonus;
      const [dx,dy] = posOnPath(en.entry, en.progress);
      const isBoss = en.kind==='boss';
      const col = ENEMY_COLOR[en.kind] || '#c9a1f0';
      burst(dx,dy,col, isBoss?18:8);
      floatText(dx,dy,'+'+(en.bounty+bountyBonus),'#f5b83d');
      sfxKill(isBoss);
      if(isBoss) addShake(8);
      enemies.splice(i,1); continue;
    }
    en.progress += en.speed*dt/1000;
    if(en.progress >= totalLenFor(en.entry)){ breach(); enemies.splice(i,1); }
  }
  updateHUD();
  if(spawnQueue.length===0 && enemies.length===0 && phase==='wave') endWave();
}

/* ---------- HUD ---------- */
function updateHUD(){
  $('shieldVal').textContent = shields;
  $('waveVal').textContent = wave;
  refreshShieldCost();
  refreshTowerButtonState();
  const danger = shields===0 && phase==='wave' && enemies.length>0;
  $('buyShieldBtn').classList.toggle('danger', danger);
  $('vignette').classList.toggle('show', danger);
}
function refreshTowerButtonState(){
  if(!selectedTower) return;
  const btn = document.getElementById('upgradeTowerBtn');
  if(!btn || selectedTower.level >= TOWER_MAX_LEVEL) return;
  btn.disabled = gold < towerUpgradeCost(selectedTower);
}

/* ---------- drawing ---------- */
function draw(){
  if(!map) return;
  const W=cv.width, H=cv.height;
  ctx.save();
  if(shake>0.3) ctx.translate((Math.random()-0.5)*shake, (Math.random()-0.5)*shake);
  ctx.fillStyle = '#0e0f18'; ctx.fillRect(0,0,W,H);
  for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++){
    const isPath = map.geo.pathSet.has(c+','+r);
    const [x,y] = [MARGIN+c*TILE, MARGIN+r*TILE];
    const spriteKey = isPath ? 'tile:path' : 'tile:floor';
    if(spriteReady(spriteKey)){
      ctx.drawImage(sprites[spriteKey], x, y, TILE, TILE);
    } else {
      ctx.fillStyle = isPath ? '#232538' : '#181a28';
      ctx.fillRect(x+1,y+1,TILE-2,TILE-2);
    }
  }
  ctx.strokeStyle = 'rgba(245,184,61,.5)'; ctx.lineWidth=3;
  map.geo.entries.forEach(lane=>{
    ctx.beginPath(); lane.waypoints.forEach(([x,y],i)=> i===0?ctx.moveTo(x,y):ctx.lineTo(x,y)); ctx.stroke();
    drawMarker(lane.waypoints[0], '#81c784', 'marker:start');
  });
  const finalLane = map.geo.entries[0];
  drawMarker(finalLane.waypoints[finalLane.waypoints.length-1], '#e57373', 'marker:end');

  let visionSources = null;
  if(map.fogOfWar){
    visionSources = towers.map(t=>({x:t.x, y:t.y, r:CARD_DB[t.key].tower.range}));
    map.geo.entries.forEach(lane=>{
      visionSources.push({x:lane.waypoints[0][0], y:lane.waypoints[0][1], r:70});
    });
    visionSources.push({x:finalLane.waypoints[finalLane.waypoints.length-1][0], y:finalLane.waypoints[finalLane.waypoints.length-1][1], r:70});
    for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++){
      const [cx,cy] = cellCenter(c,r);
      const seen = visionSources.some(s=>dist(s.x,s.y,cx,cy) <= s.r);
      if(!seen){
        ctx.fillStyle = 'rgba(6,7,12,.82)';
        ctx.fillRect(MARGIN+c*TILE, MARGIN+r*TILE, TILE, TILE);
      }
    }
  }

  for(const t of towers){
    const def = CARD_DB[t.key].tower;
    if(selectedTower===t){
      ctx.strokeStyle = '#f5b83d'; ctx.lineWidth=2;
      ctx.beginPath(); ctx.arc(t.x,t.y,26,0,Math.PI*2); ctx.stroke();
    }
    if(t.flash>0){
      ctx.strokeStyle = def.color+'55'; ctx.lineWidth=1;
      ctx.beginPath(); ctx.arc(t.x,t.y,def.range,0,Math.PI*2); ctx.stroke();
      if(t.flashTarget){
        const [fx,fy] = posOnPath(t.flashTarget.entry, t.flashTarget.progress);
        ctx.strokeStyle = def.color; ctx.lineWidth=2;
        ctx.beginPath(); ctx.moveTo(t.x,t.y); ctx.lineTo(fx,fy); ctx.stroke();
      }
    }
    if(def.kind==='auraDmg'||def.kind==='auraRate'){
      ctx.strokeStyle = def.color+'33'; ctx.lineWidth=1;
      ctx.beginPath(); ctx.arc(t.x,t.y,def.range,0,Math.PI*2); ctx.stroke();
    }
    const tSpriteKey = 'card:'+t.key;
    let towerScale = 1;
    if(t.recoil>0) towerScale -= 0.12*(t.recoil/150);
    if(t.spawnAnim>0) towerScale *= easeOutBack(1 - t.spawnAnim/300);
    if(spriteReady(tSpriteKey)){
      const ts = 48*towerScale;
      ctx.drawImage(sprites[tSpriteKey], t.x-ts/2, t.y-ts/2, ts, ts);
    } else {
      ctx.fillStyle = def.color;
      ctx.beginPath(); ctx.arc(t.x,t.y,14*towerScale,0,Math.PI*2); ctx.fill();
      ctx.strokeStyle='#0e0f18'; ctx.lineWidth=2; ctx.stroke();
    }
    for(let p=0;p<t.level;p++){
      ctx.fillStyle = '#f5b83d';
      ctx.beginPath(); ctx.arc(t.x-6+p*6, t.y+27, 2, 0, Math.PI*2); ctx.fill();
    }
  }

  for(const pr of projectiles){
    const pt = Math.min(1, pr.t/pr.dur);
    const px = pr.x + (pr.tx-pr.x)*pt, py = pr.y + (pr.ty-pr.y)*pt;
    ctx.fillStyle = pr.color;
    ctx.beginPath(); ctx.arc(px,py,4,0,Math.PI*2); ctx.fill();
    ctx.strokeStyle = pr.color+'66'; ctx.lineWidth=2;
    ctx.beginPath(); ctx.moveTo(pr.x + (pr.tx-pr.x)*Math.max(0,pt-0.18), pr.y + (pr.ty-pr.y)*Math.max(0,pt-0.18));
    ctx.lineTo(px,py); ctx.stroke();
  }

  for(const b of lightningBolts){
    const alpha = Math.max(0, b.life/b.maxLife);
    ctx.strokeStyle = 'rgba(230,220,255,'+alpha+')';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(b.x1,b.y1);
    const segs = 4;
    for(let s=1;s<segs;s++){
      const t = s/segs;
      const mx = b.x1+(b.x2-b.x1)*t, my = b.y1+(b.y2-b.y1)*t;
      const nx = -(b.y2-b.y1), ny = (b.x2-b.x1);
      const nlen = Math.hypot(nx,ny)||1;
      const jitter = (Math.random()-0.5)*10;
      ctx.lineTo(mx + (nx/nlen)*jitter, my + (ny/nlen)*jitter);
    }
    ctx.lineTo(b.x2,b.y2);
    ctx.stroke();
  }

  if(handCard && handCard.type==='tower'){
    buildable.forEach(b=>{
      if(b.occupied) return;
      const [x,y]=cellCenter(b.c,b.r);
      ctx.fillStyle = 'rgba(245,184,61,.12)';
      ctx.beginPath(); ctx.arc(x,y,20,0,Math.PI*2); ctx.fill();
    });
  }

  const ENEMY_RADIUS = { grunt:8, runner:8, swarmling:6, shielded:9, regenerator:9, brute:11, boss:13 };
  const ENEMY_PULSE = {
    grunt:{speed:4, amp:0.07}, runner:{speed:7, amp:0.08}, swarmling:{speed:9, amp:0.10},
    shielded:{speed:3, amp:0.05}, regenerator:{speed:3.5, amp:0.10}, brute:{speed:2.2, amp:0.06},
    boss:{speed:1.8, amp:0.09},
  };
  const nowSec = performance.now()/1000;
  for(const en of enemies){
    const [x,y] = posOnPath(en.entry, en.progress);
    if(visionSources && !visionSources.some(s=>dist(s.x,s.y,x,y) <= s.r)) continue;
    const isBoss = en.kind==='boss';
    const eSpriteKey = 'enemy:'+en.kind;
    const r = ENEMY_RADIUS[en.kind] || 8;
    const pc = ENEMY_PULSE[en.kind] || {speed:4, amp:0.07};
    const pulse = 1 + pc.amp * Math.sin(nowSec*pc.speed + (en.pulseSeed||0));
    if(spriteReady(eSpriteKey)){
      const s = r*3.6*pulse;
      ctx.save();
      ctx.translate(x,y);
      ctx.rotate((en.facing||0) + SPRITE_FACING_OFFSET);
      ctx.drawImage(sprites[eSpriteKey], -s/2, -s/2, s, s);
      ctx.restore();
    } else {
      ctx.fillStyle = ENEMY_COLOR[en.kind] || '#c9a1f0';
      ctx.beginPath(); ctx.arc(x,y,r*pulse,0,Math.PI*2); ctx.fill();
    }
    if(en.slowT>0){ ctx.strokeStyle='#7ec8e3'; ctx.lineWidth=2; ctx.beginPath(); ctx.arc(x,y,r+3,0,Math.PI*2); ctx.stroke(); }
    if(en.poisonT>0){ ctx.strokeStyle='#639922'; ctx.lineWidth=2; ctx.beginPath(); ctx.arc(x,y,r+6,0,Math.PI*2); ctx.stroke(); }
    if(en.shield>0){ ctx.strokeStyle='#5ec8f2'; ctx.lineWidth=2.5; ctx.beginPath(); ctx.arc(x,y,r+9,0,Math.PI*2); ctx.stroke(); }
    const w = Math.max(20, r*3.1);
    const yOff = r*2.4 + 8;
    ctx.fillStyle='#0e0f18'; ctx.fillRect(x-w/2,y-yOff,w,4);
    ctx.fillStyle='#81c784'; ctx.fillRect(x-w/2,y-yOff,w*Math.max(0,en.hp/en.maxHp),4);
    if(en.shield>0){
      ctx.fillStyle='#5ec8f2'; ctx.fillRect(x-w/2,y-yOff-5,w*Math.max(0,en.shield/en.maxShield),3);
    }
  }

  for(const p of particles){
    ctx.globalAlpha = Math.max(0, p.life/p.maxLife);
    ctx.fillStyle = p.color;
    ctx.beginPath(); ctx.arc(p.x,p.y,2.5,0,Math.PI*2); ctx.fill();
  }
  ctx.globalAlpha = 1;
  for(const f of floatTexts){
    ctx.globalAlpha = Math.max(0, f.life/f.maxLife);
    ctx.fillStyle = f.color;
    ctx.font = '11px "IBM Plex Mono"'; ctx.textAlign='center';
    ctx.fillText(f.text, f.x, f.y - (1-f.life/f.maxLife)*24);
  }
  ctx.globalAlpha = 1;
  ctx.restore();
}
function drawMarker([x,y], color, spriteKey){
  if(spriteKey && spriteReady(spriteKey)){
    ctx.drawImage(sprites[spriteKey], x-18, y-18, 36, 36);
  } else {
    ctx.fillStyle=color; ctx.beginPath(); ctx.arc(x,y,8,0,Math.PI*2); ctx.fill();
  }
}

/* ---------- toast ---------- */
let toastTimer=null;
function toast(msg, ms=2000){
  const t=$('toast'); t.textContent=msg; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>t.classList.remove('show'), ms);
}

/* ---------- loop ---------- */
function approach(current, target, dt){
  const diff = target-current;
  if(Math.abs(diff) < 0.5) return target;
  return current + diff*Math.min(1, dt*6/1000);
}
function loop(t){
  const dt = Math.min(t-lastT, 50); lastT=t;
  updateGame(dt*speedMult);
  if(map){
    goldDisplay = approach(goldDisplay, gold, dt);
    $('goldVal').textContent = Math.round(goldDisplay);
  }
  embersDisplay = approach(embersDisplay, meta.embers, dt);
  $('embersVal').textContent = Math.round(embersDisplay);
  if(shake>0) shake = Math.max(0, shake - dt*0.05);
  if(towers) towers.forEach(tw=>{
    if(tw.flash>0) tw.flash -= dt;
    if(tw.recoil>0) tw.recoil = Math.max(0, tw.recoil-dt);
    if(tw.spawnAnim>0) tw.spawnAnim = Math.max(0, tw.spawnAnim-dt);
  });
  for(let i=projectiles.length-1;i>=0;i--){
    const pr = projectiles[i];
    pr.t += dt;
    if(pr.t >= pr.dur){
      resolveProjectileImpact(pr);
      projectiles.splice(i,1);
    }
  }
  for(let i=lightningBolts.length-1;i>=0;i--){
    lightningBolts[i].life -= dt;
    if(lightningBolts[i].life<=0) lightningBolts.splice(i,1);
  }
  for(let i=particles.length-1;i>=0;i--){
    const p = particles[i];
    p.life -= dt;
    if(p.life<=0){ particles.splice(i,1); continue; }
    p.x += p.vx*dt/1000; p.y += p.vy*dt/1000;
    p.vx *= 0.94; p.vy *= 0.94;
  }
  for(let i=floatTexts.length-1;i>=0;i--){
    floatTexts[i].life -= dt;
    if(floatTexts[i].life<=0) floatTexts.splice(i,1);
  }
  draw();
  requestAnimationFrame(loop);
}
document.querySelectorAll('.speedBtn').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    speedMult = parseInt(btn.dataset.speed, 10);
    document.querySelectorAll('.speedBtn').forEach(b=>b.classList.toggle('active', b===btn));
  });
});

/* ---------- boot ---------- */
function spawnAmbientEmbers(count){
  for(let i=0;i<count;i++){
    const el = document.createElement('div');
    el.className = 'ember-particle';
    el.style.left = (Math.random()*100)+'vw';
    el.style.setProperty('--drift', (Math.random()*60-30)+'px');
    const dur = 9 + Math.random()*8;
    el.style.animationDuration = dur+'s';
    el.style.animationDelay = (-Math.random()*dur)+'s';
    document.body.appendChild(el);
  }
}

(async function boot(){
  spawnAmbientEmbers(14);
  await loadMeta();
  embersDisplay = meta.embers;
  renderMenu();
  requestAnimationFrame(t=>{ lastT=t; requestAnimationFrame(loop); });
})();
